package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService  {
	IPizzaOrderDAO dao=new PizzaOrderDAO();

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza)  throws PizzaException{

		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) {
		return null;
	}

	@Override
	public boolean validateChoice(String choice) {
		if (choice.matches(CHOICE_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateCustomerName(String customerName) {

		if (customerName.matches(CUSTOMER_NAME_PATTERN))
			return true;
		else
			return false;
	}

	@Override
	public boolean validateCustomerAddress(String customerAddress) {
		if (customerAddress.matches(CUSTOMER_ADDRESS_PATTERN))
			return true;
		else
		return false;
	}

	@Override
	public boolean  validateCustomerPhoneNumber(String customerMobileNo) {
		if (customerMobileNo.matches(CUSTOMER_MOBILE_NO_PATTERN))
			return true;
		else
		return false;
	}
	@Override
	public void storeIntoMap(Customer customer) {
		dao.storeIntoMap(customer);
	}
	double totalPrice;
PizzaOrder pizzaorder=new PizzaOrder();
	@Override
	public double price(int topping) {
	 totalPrice=350+topping;
		pizzaorder.setTotalPrice(totalPrice);
		return totalPrice;
	}

	@Override
	public void order(PizzaOrder pizzaorder) {
		dao.order(pizzaorder);
		
	}


}
