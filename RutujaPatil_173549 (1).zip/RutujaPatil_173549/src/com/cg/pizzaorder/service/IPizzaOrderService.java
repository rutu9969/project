package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public interface IPizzaOrderService {
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException;

	public PizzaOrder getOrderDetails(int orderid);


	// choice for validation
	String CHOICE_PATTERN = "[1-3]{1}";

	boolean validateChoice(String choice);

	// Name pattern for validation
	String CUSTOMER_NAME_PATTERN = "[A-Z][a-z]{1,9}";

	boolean validateCustomerName(String customerName);

	// Address pattern for validation
	String CUSTOMER_ADDRESS_PATTERN = "[A-Z][a-z]{1,50}";

	boolean validateCustomerAddress(String customerAddress);

	//	Mobileno pattern for validation
	String CUSTOMER_MOBILE_NO_PATTERN="[0-9]{10}";
	boolean validateCustomerPhoneNumber(String customerMobileNo);

	void storeIntoMap(Customer customer);
	void order(PizzaOrder pizzaorder);




	double price(int topping);

}
