package com.cg.pizzaorder.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class Client {
	public static void main(String[] args) {
		IPizzaOrderService service=new PizzaOrderService();
		PizzaOrder pizzaorder=new PizzaOrder();
		String choice;
		String name;
		String address;
		String phoneNumber;
		int topping;
		
		
		
		System.out.println("...Welcome to JustEat Pizzas...");
		while(true){
		System.out.println("Enter the option you want to go for : ");
		System.out.println("1). Place Order \n 2).Display Order \n 3. Exit");
		
		Scanner sc = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		while (true) {

			System.out.println("Enter your choice");
			choice = sc.next();

			boolean isValid = service.validateChoice(choice);

			if (isValid) {
				break;
			} else
				System.out.println("Please enter proper choice");
		}
		
		switch(choice){
		case "1":
			System.out.println("Welcome");
			while (true) {
				System.out.println("Enter the name of the customer  ");
				name = sc.next();
				boolean isValid = service.validateCustomerName(name);
				if (isValid)
					break;
				else
					System.out
							.println("Please enter proper name \nName should have maximum 10 characters and first letter must be capital ");
			}
			while (true) {
				System.out.println("Enter customer Address");
				address = sc.next();
				boolean isValid = service.validateCustomerAddress(address);
				if (isValid)
					break;
				else
					System.out.println("Please enter proper address \nFirst Letter should be capital");
			}
			while (true) {
				System.out.println("Enter customer phone number");
				phoneNumber = sc.next();
				boolean isValid = service. validateCustomerPhoneNumber(phoneNumber);
				if (isValid)
					break;
				else
					System.out.println("Please Enter proper 10 digit phone number");
			}
			
			Customer customer=new Customer();
			customer.setCustName(name);
			customer.setAddress(address);
			customer.setPhone(phoneNumber);
			service.storeIntoMap(customer);
			
		
			
		
			
			System.out.println("Pizza Toppings    Price(in Rs)");
			System.out.println("Capsicum          30");
			System.out.println("Mushroom          50");
			System.out.println("Jalapeno          70");
			System.out.println("Paneer            85");
			
			System.out.println("Enter the price  of pizza Topping preffered");
			topping=sc.nextInt();
			pizzaorder.setTopping(topping);
			pizzaorder.setCustomerId(customer.getCustomerId());
			service.order(pizzaorder);
			
		
			System.out.println(	"Price to be calculated: "+service.price(topping));
			System.out.println("pizza order successfuly placed with Order Id:"+pizzaorder.getOrderId());
			break;
		case "2":
			System.out.println("Enter the order id");
			
			
		}
		
		
		}
		
	}

}
