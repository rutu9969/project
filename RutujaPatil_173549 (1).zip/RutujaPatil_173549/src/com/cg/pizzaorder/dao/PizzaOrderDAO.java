package com.cg.pizzaorder.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderDAO implements IPizzaOrderDAO{
	
	//map for orderid as key and pizza order as value
	Map<Integer,PizzaOrder> pizzaEntry=new HashMap<>();

	
	//map for customerid as key and customer object as value
	private Map<Integer,Customer> customerEntry=new HashMap<>();


	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) {
		

		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) {
		return null;
	}
	double customerId;
	@Override
	public void storeIntoMap(Customer customer) {
		 customerId=(Math.random()*100);
		customer.setCustomerId((int)customerId);;
		customerEntry.put((int)customerId, customer);
		
	}
	double orderId;
	@Override
	public void order(PizzaOrder pizzaorder) {
		 orderId=(Math.random()*100);
		 pizzaorder.setOrderId((int)orderId);
		 pizzaEntry.put((int)orderId, pizzaorder);
	}
	public Customer find(int id)throws PizzaException
	{
		
		Customer cust=customerEntry.get(id);
		if(cust!=null)
		return cust;
		else
			throw new PizzaException("Record not found");
		
	}

}
