package com.capgemini.wallet.dao;

import java.sql.SQLException;



import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.exception.WalletException;

public interface IAccountUserDao {


	public abstract void createUser(String name,String age,String address,String email);

	
	double showBalance(int Accno) throws WalletException, SQLException;

	void depositMoney(double amount,int accno) throws WalletException;

	void withdrawMoney(double amount,int Accno) throws WalletException;


	void printTransaction(int Accno) throws WalletException;

	boolean validateAccountNo(int Accno) throws WalletException;

	void insertIntoTransaction(int Accno,String type,double amount,double balance);


	void fundTransfer(double amount, int accno, int Accno)
			throws WalletException;
	
}
