package com.capgemini.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.wallet.bean.AccountUser;
import com.capgemini.wallet.bean.Transaction;
import com.capgemini.wallet.exception.WalletException;

public class AccountUserDao implements IAccountUserDao {
	
	
	@Override
	public void createUser(String name, String age, String address, String email) {
		AccountUser au = new AccountUser();
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		
		em.getTransaction().begin();
		au.setName(name);
		au.setAge(age);
		au.setAddress(address);
		au.setEmail(email);
		em.persist(au);
		em.getTransaction().commit();
		System.out.println("One User added");
		System.out.println("Your account number is :"+au.getCode());
		em.close();
		factory.close();
		

	}
	@Override
	public boolean validateAccountNo(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();
		try {
		if(em.find(AccountUser.class,Accno)!=null){
			return true;
		}
		else
		  throw new WalletException("First create an account");
			} 
		finally{
			em.getTransaction().commit();
		}
	}
	

	

	
	@Override
	public double showBalance(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();
		
		AccountUser au = em.find(AccountUser.class, Accno);
		return au.getBalance();
	}

	@Override
	public void depositMoney(double amount, int accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();

		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, accno);
			if (au != null) {
				double bal = au.getBalance();
				au.setBalance(bal + amount);
				em.merge(au);
				em.getTransaction().commit();
				insertIntoTransaction(accno, "CR", amount, bal);
			} else {
				throw new WalletException("No such account Found ");
			}
		} finally {
			em.close();
			factory.close();
		}
	}
	@Override
	public void insertIntoTransaction(int Accno, String type, double amount,
			double balance) {
	
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
        em.getTransaction().begin();
        Transaction trans= new Transaction(Accno, type, amount,balance);
        em.persist(trans);
		em.getTransaction().commit();
		em.close();
		factory.close();
		}
		
	

	

	@Override
	public void withdrawMoney(double amount, int Accno) throws WalletException {

		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		em.getTransaction().begin();
		try {
			AccountUser au = em.find(AccountUser.class, Accno);
			if (au != null) {
				double bal = au.getBalance();
				if (bal > amount) {
					au.setBalance(bal - amount);
					em.merge(au);
					em.getTransaction().commit();
					insertIntoTransaction(Accno, "DR", amount, bal);
				} else {
					throw new WalletException("Insufficient funds");
				}
			} else {
				throw new WalletException("No such account Found ");
			}

		} finally {
			em.close();
			factory.close();
		}
	}

	@Override
	public void fundTransfer(double amount, int accno, int Accno)
			throws WalletException {

		withdrawMoney(amount, Accno);
		depositMoney(amount, accno);

	}

	@Override
	public void printTransaction(int Accno) throws WalletException {
		EntityManagerFactory factory = Persistence
				.createEntityManagerFactory("BankWalletProject");
		EntityManager em = factory.createEntityManager();
		ArrayList<Transaction> list = (ArrayList<Transaction>) em
				.createQuery(
						"Select trans from Transaction trans where Accno = :Accno order by trans,id",
						Transaction.class).setParameter("Accno", Accno)
				.getResultList();
		for (Transaction transaction : list) {
			System.out.println(transaction.printDetails());
		}

	}
}